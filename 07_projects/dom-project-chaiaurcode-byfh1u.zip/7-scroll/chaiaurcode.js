// use indicator width
